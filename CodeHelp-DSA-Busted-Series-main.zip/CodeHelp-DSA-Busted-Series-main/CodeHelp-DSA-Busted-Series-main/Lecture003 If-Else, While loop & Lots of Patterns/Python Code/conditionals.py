a = int(input("Enter the value of a : "))
if a >0:
    print("A is positive")
elif a<0:
    print("A is negative")
else:
    print("A is 0")
