n = int(input())
i = 0 

while(i < n):
    j = 0
    while(j < n):      
        j = j + 1
        print('*', end="")
    i = i + 1
    print('')
