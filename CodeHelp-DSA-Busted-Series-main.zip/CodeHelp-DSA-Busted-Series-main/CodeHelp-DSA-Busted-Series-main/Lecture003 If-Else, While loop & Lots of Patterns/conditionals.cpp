#include<iostream>
using namespace std;

int main() {
    //int a;
    //cin>>a; 

    //cout<<" value of n is :" << n <<endl;

    //if a is positive
    /*
    if(a>0) {
        cout<<" A is Positive" << endl;
    }
    else{
        cout<<" A is negative" << endl;
    }


   int a,b;

   cout<<"Enter the value of a "<<endl;
   cin>>a;
   cout<<"Enter the value of b "<<endl;
   cin>>b;

    if(a>b) {
        cout<<" A is greater " << endl; 
    }
    if(b>a) {
        cout<<" B is greater " << endl;
    }

    */

   int a ;
   cout<<" enter the value of a "<<endl;
   cin>>a;



   if(a>0) {
       cout<<" A is positive"<< endl;
   }
   else if(a<0) {
       cout<<" A is negative"<<endl;
   }
   else {
       cout<<" A is 0"<<endl;
   }



}