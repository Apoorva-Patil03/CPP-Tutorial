// #include<iostream>
// using namespace std;

// void printArray(int arr[], int n) {

//     for(int i = 0; i<n; i++ ) {
//         cout<< arr[i] <<" ";
//     }cout<<endl;

// }

// void swapAlternate(int arr[], int size) {

//     for(int i = 0; i<size; i+=2 ) {
//         if(i+1 < size) {
//             swap(arr[i], arr[i+1]);
//         }
//     }

// }

// int main() {

//     int even[8] = {5,2,9,4,7,6,1,0};
//     int odd[5] = {11, 33, 9, 76, 43};

//     swapAlternate(even, 8);
//     printArray(even, 8);

//     cout << endl;

//     swapAlternate(odd, 5);
//     printArray(odd, 5);



//     return 0;
// }

//for traversing u know always use a for loop(done)
#include<iostream>
using namespace std;
void printArray(int arr[],int size){
    cout << "Array after swap is : " << endl;
    for (int i = 0; i < size; i++){
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}
void swapalternate(int arr[],int size){
    for(int i=0;i<size;i+=2){
        if(i+1<size){
            swap(arr[i], arr[i + 1]); // or if not available write swap function as --> i = temp , i+1 = i,  temp = i+1
        }
    }
}

int main(){
    int size, arr[100];
    cout<<"Enter the array along with it's size : "<<endl;
    cin>>size;
    for(int i=0;i<size;i++){
        cin>>arr[i];
    }
    swapalternate(arr,size); //only mention name of array not along with bracket of size
    printArray(arr,size); //u have written this after swap alternate hence it would show swapped array even though u wrote print fun before swap fun calling order matters
    return 0;
}