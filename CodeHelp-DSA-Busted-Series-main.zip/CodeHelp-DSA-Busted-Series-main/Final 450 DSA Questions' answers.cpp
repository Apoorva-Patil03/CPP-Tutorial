#include<iostream>
using namespace std;
void reverseArray(int arr[], int start , int end, int size){
  //for (int i=0;i<size;i++){ //actual no need but won't give error if u keep this line
    while(start<end){ //essential condition
    int temp = arr[start];
    arr[start] = arr[end];
    arr[end] = temp;

    start++;
    end--;
    }
    }
  //}
       
  void printArray(int arr[],int size){
    cout<<" Reversed array is : " <<endl;
    for(int i=0; i<size;i++){
      cout<<arr[i]<<" ";
    }
  }
       
//this code is for taking input from user
// int main(){
//   int size,arr[100];
//   cin>>size;
//   for(int i=0;i<size;i++){
//   cin>>arr[i];
//   }
//   int start = 0;
//   int end = size - 1;
//   reverseArray(arr,  start ,  end,  size);
//   printArray( arr, size);
//   return 0;
// }

//this is code is for input from code directly
  int main()
  {
    int arr[] = {1, 2, 3, 4, 5, 6};

    // To print original array
    printArray(arr, 6);

    // Function calling
    reverseArray(arr, 0, 5);

    cout << "Reversed array is" << endl;

    // To print the Reversed array
    printArray(arr, 6);

    return 0;
  }
