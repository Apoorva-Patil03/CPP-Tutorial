// #include<iostream>

// using namespace std;

// // int power(int a,int b){ //from here function body starts
// // //power is name of function which will return an int value also having parameters which are both int data type
// // //known as function definition  
// // Above one is first method

// int power(){ //3rd method without arguments
// int a,b ;
// cin>>a>>b;
// int ans=1;

// for(int i=1;i<=b;i++){
//     ans=ans*a;
// }
// return ans;  //return type is int which is defined on 5th line
// }

// int main() //main function is where all other functions are called inside of it
// {
//     // int a,b ;
//     // cin>>a>>b;

//     // int answer = power(a,b); //here return value by function is stored
//     // cout<<"answer is: "<<answer<<endl; 

//     // int c,d ;
//     // cin>>c>>d;

//     // int answer = power(c,d); // 2nd method of defining function: values respective to that particular data type matters the most
//     // cout<<"answer is: "<<answer<<endl; 


//     cout<<"Answer for: "<<endl<<power()<<endl; //3rd method also it matters how many times we run this line as that much times we can find our 'answer'
//     return 0;

// }

// //Whatever variables we define in particular in particular function those became local variables of that function can not be accessed by other functions
// please keep names of functions mostly relevant to the job they will perform in function



// #include<iostream>
// using namespace std;

// //if even give 0 if odd give 1
// bool isEven(int a)
// {
//     if(a%2==0){ //can use (a&1) also
//         cout<<"Number is even"<<endl;
//         return 0;
//     }
//     else{
//         cout<<"Number is odd"<<endl;
//         return 1;
//     }
// }
// int main(){
//     int num;
//     cin>>num;

//     int ans=isEven(num);
//     cout<<"Answer is: "<<ans<<endl;
// }

// #include<iostream>
// using namespace std;

// int fact(int n) //function fact defined along with two parameters
// {
//     int fact=1;
//     for(int i=1;i<=n;i++)
//     {
//         fact=fact*i;
//     }
//     return fact;
// }

// int nCr(int n,int r) { //function ncr defined
//     //nCr is permutation and n is total number of ways and r is number of ways which are taken in consideration out of n for given problem
//     int numerator=fact(n);  //function fact defined
//     int denominator=fact(r)*fact(n-r);
//     int ans=numerator/denominator; //can directly write return here
//     return ans;
// }
// int main(){
// int n,r;
// cin>>n>>r;
// cout<<"answer is: "<<nCr(n,r)<<endl;   //function call of ncr
// }


// #include<iostream>
// using namespace std;

// void printNumberCounting(int num){  // function signature or definition
// for (int i = 0; i <=num; i++)
// {
//     /* code */
//     cout<<i<<" ";
// }
// cout<<endl;

// }
// int main(){
//     int n;
//     cin>>n;
//     printNumberCounting(n);
//     return 0;
// }


// #include<iostream>
// using namespace std;
// bool isPrime(int n){
//     for(int i=2;i<n;i++){
//         if(n%i==0){
//             return 0;
//         }
//     }
//     return 1;
// }

// int main(){
//     int n;
//     cin>>n;
//     if(isPrime(n)){
//         cout<<"It is prime no."<<endl;
//     }
//     else{
//         cout<<"It is not prime no."<<endl;
//     }
// }
// We can write return statement as void given by--> return ; --> it won't occur any error


#include<iostream>
using namespace std;
void dummy(int n)    //pass by value example
{
    n++;
    cout<<"n is: "<<n<<endl;
}

int main()
{
    int n;
    cin>>n;
    dummy(n);
    cout<<"Number n is: "<<n<<endl;
    return 0;
}