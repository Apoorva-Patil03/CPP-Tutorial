//Binary Search
// List should be in monotonic form like either ascending or descending order.
// first find mid element then compare mid element with key then if not equal then compare if key 
//is greater than or less than mid element and render search list into half accordingly and repeat till number is found
//Best case: O(1)
//Worst case:O(logn )
//As we always divide search list in 2 hence we can say n/2k and derive by using log
//Applications:lower and upper bound,number of occurances,pivot array element,rotated array search,search space small so that agg cow,roti,book allocation problems we can solve.

//Implementation:

#include<iostream>
using namespace std;

int binarySearch(int arr[],int size,int key){
    int start=0;
    int end=size-1;
    int mid=(start+end)/2;
//Here we should use formula int mid= start +(end-start)/2; because if start and
// end values of search list are quite big as extremes -2^31 to 2^31-1 then we can add up them like above 
//formula so we can use this formula so that result won't go out of bound

    while(start<=end){
        if(arr[mid]==key)
        {
           return mid;
        }
        //go to right part
        if(key>arr[mid]){
            start=mid+1;
        }
        else{
            end=mid-1;
        }
        mid=(start+end)/2;
    }
    return -1;
}
int main()
{
    int even[6]={2,4,6,8,12,18};
    int odd[5]={3,8,11,14,16};

    int Evenindex=binarySearch(even,6,12);
    cout<<"Index of 12 is: "<<Evenindex<<endl;

     int Oddindex=binarySearch(odd,5,14);
    cout<<"Index of 12 is: "<<Oddindex<<endl;

    return 0;
}

 