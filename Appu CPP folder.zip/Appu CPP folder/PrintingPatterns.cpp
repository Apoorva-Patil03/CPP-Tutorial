// #include<iostream>
// using namespace std;
// int main(){
//     int n;
//     cin>>n;
//     int i=1;
//     while(i<=n)
//     {
//         int j=1;
//         while(j<=n)
//         {
//             /* code */
//             cout<<j;  //here if we write n-j+1 then pattern will be reversed
//             j++;
//         }
//         cout<<endl;
//         i++;
        
//     }
// }

// #include<iostream>
// using namespace std;
// int main(){
//     int n;
//     cin>>n;

//     int i=1;
//     int count=1;
//     while(i<=n){
//         int j=1;
//         while(j<=n){
//             cout<<count<<'\t';
//             count++;
//             j++;
//         }
//         cout<<endl;
//         i++;
//     }
// }

// #include<iostream>
// using namespace std;
// int main(){
//     int n;
//     cin>>n;
//     int i=1;
//     while(i<=n){
//         int j=1;
//         while(j<=i){
//             cout<<"*";
//             j++;
//         }
//      cout<<endl;
//      i++;
//     }
// }

// #include<iostream>
// using namespace std;
// int main(){
//     int n;
//     cin>>n;
//     int i=1;
//     while(i<=n){
//         int j=1;
//         while(j<=i){
//             cout<<i;
//             j++;
//         }
//         cout<<endl;
//         i++;
//     }
// }

// #include<iostream>
// using namespace std;
// int main(){
//     int n;
//     cin>>n;

//     int i=1;
//     int count=1;
//     while(i<=n){
//         int j=1;
//         while(j<=i){
//             cout<<count<<'\t';
//             count++;
//             j++;
//         }
//         cout<<endl;
//         i++;
//     }
// }

// #include<iostream>
// using namespace std;
// int main(){
//     int n;      //n=height,i=total no. of rows and j=total no. of columns
//     cin>>n;

//     int i=1;
//     int count=1;
//     while(i<=n){   
//         int j=1;
//         int value=i;
//         while(j<=i){
//             cout<<value<<'\t';
//             value++;  //we are printing both rows and columns instead of just printing columns
//             j++;
//         }
//         cout<<endl;
//         i++;
//     }
// }

// #include<iostream>
// using namespace std;
// int main(){
//     int n;
//     cin>>n;

//     int i=1;
//     int count=1;
//     while(i<=n){
//         int j=1;
//         while(j<=i){
//             cout<<i-j+1<<'\t';
//             j++;
//         }
//         cout<<endl;
//         i++;
//     }
// }

// #include<iostream>
// using namespace std;
// int main(){
//     int n;
//     cin>>n;

//     int i=1;
//     while(i<=n){
//         int j=1;
//         while(j<=n){
//             char ch='A'+i-1;  //we are getting here ame character row wise but if we want same character column wise just replace i with j
//             cout<<ch<<'\t';
//             j++;
//         }
//         cout<<endl;
//         i++;
//     }
// }

#include<iostream>
using namespace std;
int main(){
    int n;
    cin>>n;
    int i=1;
    while(i<=n){
        int j=1;
        
    }
}