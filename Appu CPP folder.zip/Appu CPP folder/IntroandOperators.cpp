// #include<iostream>
// using namespace std;
// int main(){
//     cout<<"Hello World :) "<<endl; //Refer to notebook
// }

// #include<iostream>
// using namespace std;
// int main(){
//     int a=123;
//     cout<<a<<endl;

//     // char a=123;   //Here we cant declare 2 variables with same name hence use different names for diffrernt variables in same block
//     // cout<<a<<endl;

//     char b='a';
//     cout<<b<<endl; //we can give only single character in char type variable for entering multiple characters use strings

//     bool bl=true;
//     cout<<bl<<endl;

//     float f=1.2;
//     cout<<f<<endl;

//     double d=1.23;
//     cout<<d<<endl;

//     //Use of sizeof opertor is we can find size of that data type in bytes
//     int size=sizeof(a);
//     cout<<"Size is: "<<size<<endl;
//      //Find size for b,bl,f,d also.
// }

// #include<iostream>
// using namespace std;
// int main(){
//     //Typecasting
//      int a= 'a';    //char to int
//      cout<<a<<endl;

//      char ch=98;    //int to char
//      cout<<b<<endl;

//      char ch1=123456;
//      cout<<ch1<<endl; //here output will be 64 which is shown as @ because we are trying to fit 4 bytes of int 123456 in 1 byte of char hence only last byte will be stored from 123456 which is showing 64 in binary
      
//      unsigned int c=112;
//      cout<<c<<endl;

//      unsigned int d=-112; //very large number because we would do 2's complement but it is negative number MSB will be 1 hence it would give large number
//      cout<<d<<endl;
// }

// #include<iostream>
// using namespace std;
// int main(){
//     // Arithmetic Operators
//     int a=2/5;
//     cout<<a<<endl; // int/int=int

//     float b=2.0/5;
//     cout<<b<<endl; // float/int=float

//     double c=2.01/5;
//     cout<<c<<endl; //double/int=double

//     int d=3*2;      //don't perform multiplication whose ans would be beyond limit or very large
//     cout<<d<<endl;

//     int e=2+3;      //don't perform addition whose ans would be beyond limit or very large
//     cout<<e<<endl;

//     int f=34-23;
//     cout<<f<<endl; //perform once unsigned subtraction whose ans would be negative
// }

// #include<iostream>
// using namespace std;
// int main(){
//     //relational operators

//     int a=2;
//     int b=8;

//     bool applet(a==b);
//     cout<<applet<<endl;

//     bool apple(a>=b);
//     cout<<apple<<endl;

//     bool appl(a<=b);
//     cout<<appl<<endl;

//     bool app(a<b);
//     cout<<app<<endl;

//     bool ap(a>b);
//     cout<<ap<<endl;

//     bool a(a!=b);
//     cout<<a<<endl;

//     int a=0;
//     cout<<!a<<endl; //Negation

// }
