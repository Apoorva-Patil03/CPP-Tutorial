//Time Complexity:
//It is the amount of time taken by an algorithm to run
//As a function of length of the input

//Why to find time complexity: For making better programs is it optimized or not we have to check by these 
//Comparison of two algorithms for problem solving so that most optimal one will be chose
//Upper Bound: Big-O notation which states worst case or limits of particular program or algorithm so that we get 
//to know actual efficiency hence we discuss about Big-O the most
//Average Bound : Theta
//Lower Bound: Omega which states the best case of algorithm

//constant time: O(1) -->Running for loop for particular given times for e.g. 10 times as we already know n or constant
// number of how many times we gonna run loop
//Linear time: O(n) --> Running for loop n times
//Logarithmic time: O(log n) -->Binary search
//Quadratic time: O(n^2) --> two nested for loops
//Cubic time: O(n^3) --> three nested for loops

//Complexity will increase as:
//O(1)<O(log n)<O(n)<O(n log n)<O(n^2)<O(n^3)<O(2^n)<O(n!)
//while keeping this complexity order in mind we have to ignore the lower complexity and constants 
//we will solve problems of recursion and most of modern machines can run 10^8 operations per second hence there is a 
//chart in mind we have to keep that in case of coding platforms we cant apply any complexity to any given range of or time
// limit exceeding problem will occur (mostly apply high complexity to lower range of n)
//If loops are separate then we will add them as O(n+m) and if loops are nested then multiply them like O(n*n)=O(n^2) for 2 nested loops 

//Space complexity:
//It represents the memory taken by your program as function of input
//variables denotes constant space complexity when fixed number of variables(size) are stored as int arr[5]={1,2,3,4,5} is
// constant as we already know size
//space and time complexity is not same always as we always measure space complexity on basis of how much memory was taken no 
//matter how much time it took



