// #include<iostream>
// using namespace std;

// //hold and wait and do another program for it separately
// void printArray(){


// }


// int main(){

//     //declare
//     int number[15];

//     //accessing an array
//     cout<<"value at 14 index: "<<number[14]<<endl;
// //for accessing 14th index also index starts from 0
//     cout<<"value at 20 index: "<<number[20]<<endl;
// //error occurs here as for accessing 20th index array should be 21 length

// cout<<endl<<"Everything is fine "<<endl;

// //print an array
// int b[20]={1,2,3,4};  //if we don't give values then array will fill those values by first initialized value of i which is 0

// int n=18;
// cout<<"Printing an array"<<endl;
// for (int i = 0; i < n; i++) //but we can't initialize all values with zero
// {
//     /* code */
//      cout<<b[i]<<" ";
// }
// cout<<endl;
// // also if we mentioned array of low size and try to fill more values then it returns garbage value

// int e=sizeof(number)/sizeof(int); //total size which is actually consumed by array
// cout<<e;
// }





//Character array printing
// #include<iostream>
// using namespace std;
// // void printArray(int arr[],int size)
// // {
//     // cout<<"Printing an array: "<<endl;  //this was expected in above function block of hold and wait
//     // //print an array
//     // for(int i=0;i<=size;i++){
//     //     cout<<arr[i]<<" ";
//     // }
//     // cout<<"Printing done"<<endl;
// // }
// int main(){
//     char ch[5]={'a','b','c','d','e'};
//     cout<<"Printing an array: "<<endl;
//     //print an array
//     for(int i=0;i<=5;i++){
//         cout<<ch[i]<<" ";
//     }
//     cout<<"Printing done"<<endl;

    
//     // cout<<ch[3]<<endl;
//     // printArray(ch); //if function carrying parameter type as int then we can't pass character type variable in function call
// }




// #include<iostream>
// using namespace std;
// int getMin(int num[],int n){  //here assume that INT_MIN is minimum value of int 2^-31 and INT_MAX is 2^-31 - 1 (default case)

//     int min=INT_MAX;

//     for (int i = 0; i<n; i++)
//     {
       
//         /* code */
//         if (num[i]<min)
//         {
//             /* code */
//             min=num[i];
//         }
        
//     }
//     return min;
// }
// int getMax(int num[],int n){  //here assume that INT_MIN is minimum value of int 2^-31 and INT_MAX is 2^-31 - 1 (default case)

//     int maxi =INT_MIN;

//     for (int i = 0; i <n; i++)
//     {
//          maxi=max(maxi,num[i]); //2nd method direct definition same we can do with minimum function
//         /* code */
//         // if (num[i]>max)
//         // {
//         //     /* code */
//         //     max=num[i];
//         // }
        
//     }
//     return maxi;
// }
// int main(){
//     int size;   //keep variables as relevant too like if we are taking array size from user then describe(declare) it as size
//     cin>>size;

//     //int num[size];  //bad practice in arrays may use in pointers
//     int num[100];
//     for (int i = 0; i < size; i++)  //when initialize i=1 then keep condition that i<=size
//     {
//         /* code */
//         cin>>num[i];
//     }
//     cout<<"Maximum value of array is :"<<getMax(num,size)<<endl;
//     cout<<"Minimum value of array is :"<<getMin(num,size)<<endl;
// }






// #include<iostream>
// using namespace std;

// void update(int arr[],int n){
//     cout<<"Inside the function"<<endl;
 
//     //updating first element of array
//      arr[0]=120; //no error
//      //Firstly when we were studying about pass by value then only value used to pass from one function to another function
//      //Hence for example there are two functions main and update then in this variable's value would simply pass to update function to perform the operation hence any updation done in update function won't affect to main function
//      //But here in case of arrays we perform pass by reference in which we refer starting address or address of first element we pass to update function from main function so that we simply accssing (not passing whole array)array of main function via update function hence any change made in update function will reflect in main function also 
//      //hence line no. 132 won't show any error in arrays 
//     //printing the array

// for (int  i = 0; i < 3; i++)
// {
//     /* code */
//     cout<<arr[i]<<" ";
// }
// cout<<endl;
// cout<<"Going back to main function"<<endl;

// }

// int main()
// {

//     int arr[3]={1,2,3};
//     update(arr,3); //function call
//     for (int i = 0; i < 3; i++)
//     {
//         /* code */
//         cout<<arr[i]<<" ";
//     }
//     cout<<endl;
//     return 0;
// }



// #include<iostream>
// using namespace std;

// //linear search is  searching technique where we search particular key by comparing elements from array one by one
//Time and space Complexity of linear search is O(n) (Big-O of n)
//Best case: O(1)
//Worst case: O(n)



// bool Search(int arr[],int size,int key)
// {
//     for (int i = 0; i < size; i++)
//     {
//         /* code */
//         if (arr[i]==key)
//         {
//             return 1;
//         }
//     }
//     return 0;    
// }

// int main()
// {
//     int arr[10]={4,2,45,-98,1,34,-56,3,-90,-5};
//     //whether -5 is present or not
//     cout<<"Enter the element to search for: "<<endl;
//     int key;
//     cin>>key;

//     bool found=Search(arr,10,key); //function call

//     if(found){
//         cout<<"Key is present"<<endl;
//     }
//     else{
//         cout<<"Key is absent"<<endl;
//     }


//     return 0;
// }




#include<iostream>
using namespace std;

void reverse(int arr[],int n){
    int start=0;
    int end=n-1;

    while (start<=end)
    {
        /* code */
        swap(arr[start],arr[end]);
            start++;
            end--;
        
    }
    
}
void printArray(int arr[],int n)
{
    for (int i = 0; i <n ; i++)
    {
        /* code */
        cout<<arr[i]<<endl;
    }
    cout<<endl;
}
int main() //we can do this only if order is asceending
{
    int arr[6]={1,4,0,5,-2,15};
    int brr[5]={2,6,3,9,4};

    reverse(arr,6);
    reverse(brr,5);

    printArray(arr,6);
    printArray(brr,5);

    return 0;
}