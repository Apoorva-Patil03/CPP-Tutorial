// #include<iostream>
// using namespace std;
// int main()
// {
//     // int a;
//     // cin>>a;

//     // //if a is positive
//     // if(a>0){
//     //     cout<<"A is positive"<<endl; //if condition fails then control will transfer to else block
//     // }
//     // //if a is negative
//     // else{
//     //     if(a<0){         //instead of this we can use if - else-if block
//     //     cout<<"A is negative"<<endl;
//     //     }
//     //     else{
//     //         cout<<"A is zero"<<endl;
//     //     }
//     // }

//     // //cin doesn't read space,tab,enter for reading them cin.get()
//     // b=cin.get();
//     // cout<<"value of b is:"<<b<<endl;
//     // //even if there are 2 input variables and even we give only one input still code can run

//     // int a,b;
//     // cin>>a>>b;
//     // //if a is greater
//     // if(a>b){
//     //     cout<<"A is greater"<<endl; //if condition fails then control will transfer to else block
//     // }
//     // //if b is greater
//     // if(b>a){  //can use elseif
//     //     cout<<"B is greater"<<endl;
//     // }

//     //If - elseif block representaion
//     //if a is positive
// //     if(a>0){
// //         cout<<"A is positive"<<endl; //if condition fails then control will transfer to else block
// //     }
// //     //if a is negative
// //     else if(a<0){
// //         cout<<"A is negative"<<endl;
// //         }
// //     //if a is zero
// //     else {
// //             cout<<"A is zero"<<endl;
// //         }

// // }

// Displaying numbers until counter is running
//  #include<iostream>
//  using namespace std;
//  int main();
//  {
//      int n;
//      cin>>n;
//      int i=1;
//      while(i<=n)
//      {
//          cout<<i<<" ";
//          i=i+1;  //Increment can be written as i++
//      }
//  }

// sum of all n numbers
//  #include<iostream>
//  using namespace std;
//  int main();
//  {
//      int n;
//      cin>>n;
//      int i=1;
//      int sum=0;
//      while(i<=n){
//          sum=sum+i;
//          i++;
//      }
//      cout<<"Value of num is: "<<sum<<endl;
//  }

// Try sum of even nos. and fahrenheit to celsius conversion

// Is number prime or not?
//  #include<iostream>
//  using namespace std;
//  int main();
//  {
//      int n;
//      cin>>n;
//      int i=2;
//      while(i<=n){
//          if(n%i==0)
//          {
//              cout<<"Not prime for "<<i<<endl;
//          }
//          else
//          {
//              cout<<"prime for "<<i <<endl;
//          }
//          i++;
//      }
//  }

// print stars where rows and columns are equal
//  #include<iostream>
//  using namespace std;
//  int main();
//  {
//      int n;
//      cin>>n;
//      int i=1;
//      while(i<=n){
//          int j=1;
//          while(j<=n){
//              cout<<"*";
//              j++;
//          }
//          cout<<endl;
//          i++;
//      }
//  }

// In every row a particular number printed will be same and increment of that number as per row increment
#include <iostream>
using namespace std;
int main()
{
    int n;
    cin >> n;
    int i = 1;
    while (i <= n)
    {
        int j = 1;
        while (j <= n)
        {
            cout << i;
            j++;
        }
        cout << endl;
        i++;
    }
}