// Hello world printing program:
//  #include<iostream>
//  using namespace std;
//  int main(){
//      cout<<"Hello World";
//  }

// Taking input from user:
//  #include <iostream>
//  using namespace std;
//  int main()
//  {
//      string name;
//      cout<<"Enter The Name: ";
//      cin>>name;

//     cout << "Entered name is: " << name;
//     return 0;
// }

// Input taking in C++
//  #include <iostream>
//  using namespace std;
//  int main()
//  {
//      int i;
//      cout<<"Enter a number: "<<endl;
//      cin>>i;
//      cout<<"Given number is: "<<i<<endl;
//      return 0;
//  }

// Addition using function
//  #include <iostream>
//  using namespace std;
//  int addTwoNumbers(int a, int b)
//  {
//      return a + b;
//      return a-(-b);
//  }
//  int main()
//  {
//      int a, b;
//      cout << "Enter the first number: ";
//      cin >> a;
//      cout << "Enter the second number: ";
//      cin >> b;
//      cout << "Sum of two numbers is : " << addTwoNumbers(a, b);

//     return 0;
// }

// //we can take different variables and just reference them with function
// #include <iostream>
// using namespace std;
// int addTwoNumbers(int a,int b){
//    return a+b;
// }
// int main(){
//     int x,y;
//     cout<<"Enter the first number: ";
//     cin>>x;
//     cout << "Enter the second number: ";
//     cin>>y;
//     cout<<"Sum of two numbers is : "<<addTwoNumbers(x,y);

//     return 0;
// }

// swapping two numbers using pointers and functions so that This method is particularly useful when you want
// to modify variables in a function also reflect those modifications outside of the function(hence this method is known as call by reference).
// #include <iostream>
// //#include <bits/stdc++.h> (here we can use inbuilt swap function)
// using namespace std;
// void swapTwoNumbers(int *a,int *b){
//     int temp;
//     temp = *a;
//     *a = *b ;
//     *b = temp ;
//     //here u done some glitch but remember this is how swapping done
// }

// int main(){
//     int a,b;
//     cout << "Enter the first number: "<<endl;
//     cin >> a;
//     cout << "Enter the second number: "<<endl;
//     cin >> b;
//     cout << "Before swapping two numbers :" << a << " " << b << endl;
//     swapTwoNumbers(&a, &b);
//     cout << "After swapping two numbers :";
//     cout<< a << " " << b << endl;
// }

//  no match for 'operator<<' (operand types are 'std::basic_ostream<char>' and 'void')
//    92 |     cout << "After swapping two numbers :" << swapTwoNumbers(&a, &b);  (Here I faced small error)

// C++ program to swap two numbers using 3rd variable without pointers and functions (maybe call by value method if we used functions here)
// #include <bits/stdc++.h>
// using namespace std;
// int main()
// {
//     int a = 2, b = 3;
//     //(you can take these variables' values from user also)
//     cout << "Before swapping a = " << a << " , b = " << b << endl;
//     int temp;
//     temp = a;
//     a = b;
//     b = temp;
//     cout << "After swapping a = " << a << " , b = " << b
//          << endl;

//     return 0;
// }

// C++ program to swap two numbers without using 3rd variable without pointers and functions (maybe call by value method if we used functions here)

// #include <bits/stdc++.h>
// using namespace std;
// int main()
// {
//     int a = 2, b = 3;
//     cout << "Before swapping a = " << a << " , b = " << b << endl;
//     b = a + b;
//     a = b - a;
//     b = b - a;
//     cout << "After swapping a = " << a << " , b = " << b << endl;
//     return 0;
// }

// C++ program to find the size of int, char, float, double, short int e, unsigned short int , unsigned int , long int , unsigned long int , long long int ,
// unsigned long long int , unsigned char , bool data types (in bytes)
// #include <iostream>
// using namespace std;

// int main()
// {
//     int a;
//     char b; //this is signed one
//     float c;
//     double d;
//     short int e;
//     unsigned short int f;
//     unsigned int g;
//     long int h;
//     unsigned long int i;
//     long long int j;
//     unsigned long long int k;
//     unsigned char l;
//     bool m;

//     // Calculate and Print the size of integer
//     cout << "Size of int is: " << sizeof(a) << "\n";

//     // Calculate and Print the size of char
//     cout << "Size of char is: " << sizeof(b) << "\n";

//     // Calculate and Print the size of float
//     cout << "Size of float is: " << sizeof(c)<< "\n";

//     // Calculate and Print the size of double
//     cout << "Size of double is: " << sizeof(d) << "\n";

//     // Calculate and Print the size of short int
//     cout << "Size of short int is: " << sizeof(e) << "\n";

//     // Calculate and Print the size of unsigned short int
//     cout << "Size of unsigned short int is: " << sizeof(f) << "\n";

//     // Calculate and Print the size of unsigned int
//     cout << "Size of unsigned int is: " << sizeof(g) << "\n";

//     // Calculate and Print the size of long int
//     cout << "Size of long int is: " << sizeof(h) << "\n";

//     // Calculate and Print the size of unsigned long int
//     cout << "Size of unsigned long int is: " << sizeof(i) << "\n";

//     // Calculate and Print the size of long long int
//     cout << "Size of long long int is: " << sizeof(j) << "\n";

//     // Calculate and Print the size of unsigned long long int
//     cout << "Size of unsigned long long int is: " << sizeof(k) << "\n";

//     // Calculate and Print the size of unsigned char
//     cout << "Size of unsigned char is: " << sizeof(l) << "\n";

//     // Calculate and Print the size of boolean
//     cout << "Size of boolean is: " << sizeof(m) << "\n";

//     return 0;
// }

// C++ Program To Multiply Two Floating-Point Numbers
// #include <iostream>
// using namespace std;
// float multiply(float a, float b){
//     return a*b;
// }

// int main(){
//     float a,b;
//     //if you by mistake initialize variables here as int type casting will done
//     cout << "Enter the first number: "<<endl;
//     cin>>a;
//     cout << "Enter the second number: "<<endl;
//     cin>>b;
//     cout<<"Multiplication of two float number is : "<<multiply(a,b); //but when calling function wasn't void then I didn't got any error
// }

// C++ Program To Print ASCII Value of a Character
// #include <iostream>
// using namespace std;
// int main()
// {
//     int a='a';
//     // typecasting done 
//     //but in c language we have to declare variable as char only like char a='a';
//     cout<<"ASCII value of a is : "<<a;
//     return 0;
// }


//C++ Program To Convert Fahrenheit To Celsius : T(°C) = (T(°F) - 32) × 5/9
// #include<iostream>
// using namespace std;
// float temprature(float n){
//     float celsius = (n-32) * 5/9;
//     return celsius;
// }

// int main(){
//     float n;
//     cout<<"Enter temprature in fahrenheit : "<<endl;
//     cin>>n;
//     cout << "Temprature in celsius is : " << temprature(n);
// }

// C++ Program To Convert Fahrenheit To Celsius : T(°F) = (T(°C) - 32) × 9/5
// #include <iostream>
// using namespace std;
// float temprature(float n)
// {
//     float fahrenheit = (n) * 9 / 5 + 32;
//     return fahrenheit;
// }

// int main()
// {
//     float n;
//     cout << "Enter temprature in celsius : " << endl;
//     cin >> n;
//     cout << "Temprature in fahrenheit is : " << temprature(n);
// }


//C++ Program To Find Simple Interest
// #include<iostream>
// using namespace std;
// float simpleInterest(float p,float r,int t){
//     float SI=(p*r*t)/100;
//     return SI;
// }

// int main (){
//     float p,r,t;
//     cout<<"Enter principal, rate of interest,time : ";
//     cin>>p>>r>>t;
//     cout<<"Simple Interest based on input is : "<<simpleInterest(p,r,t);
//     return 0;
// }


// C++ Program To Find compound Interest
// #include <iostream>
// #include <bits/stdc++.h>
// using namespace std;
// double compoundInterest(float p, float r, int t)
// {
//     double Amount = p*((pow((1 + r/ 100), t))); //don't know how pow function is working maybe it referred stl after all
//     double CI = Amount - p;
//     return CI;
// }

// int main()
// {
//     double p, r, t;
//     cout << "Enter principal, rate of interest,time : ";
//     cin >> p >> r >> t;
//     cout << "Compound Interest based on input is : " << compoundInterest(p, r, t);
//     return 0;
// }


// c++ program to Find Area And Perimeter Of Rectangle
// #include <iostream>
// #include <bits/stdc++.h>
// using namespace std;
// float areaRectangle(int l, int b)
// {
//     return l*b;
// }
// float perimeterRectangle(int l, int b)
// {
//     return 2*(l+b);
// }

// int main()
// {
//     int a,b;
//     cout<<"Enter length and breadth of rectangle : "<<endl;
//     cin>>a>>b;
//     cout << "Area = " << areaRectangle(a, b) << endl;
//     cout << "Perimeter = " << perimeterRectangle(a, b);
//     return 0;
// }