// C++ Program To Check Whether Number is Even Or Odd:
// #include <iostream>
// using namespace std;
// int evenOdd(int n)
// {
//     return (n % 2 == 0);
// }

// int main()
// {
//     int n;
//     cout<<"Enter the number to check: ";
//     cin >> n;
//     if (evenOdd(n))
//     {
//         cout << "Even number";
//     }
//     else
//     {
//         cout << "Odd number";
//     }

//     return 0;
// }

// C++ Program to Find Largest Among Three Numbers
//  #include<iostream>
//      using namespace std;
//  void greaterNumber(int a, int b, int c){
//      if (a > b && a > c)
//      {
//          cout << a <<" is greatest number!";
//      }
//      else if(a < b && b > c){
//          cout<< b <<" is greatest number!";
//      }
//      else{
//          cout << c <<" is greatest number!";
//      }
//  }
//  int main(){
//      int a,b,c;
//      cout << "Enter all three numbers to find greatest number! : ";
//      cin>>a>>b>>c;
//      greaterNumber(a,b,c);
//      //cout<<"Greater number is:";
//  }

// here we can also use inbuilt function called max() here

// C++ program to find largest among three numbers using temporary variable
// #include <bits/stdc++.h>
// using namespace std;
// int main()
// {
//     int a = 1, b = 10, c = 4; //we can take these values from user too

//     // temporary variable where we assumed a is max
//     int max = a;
//     if (max < b)
//         max = b;
//     if (max < c)
//         max = c;
//     return 0;
// }

// C++ Program to Check Whether a Character is a Vowel or Consonant
//  #include<iostream>
//  using namespace std;
//  void vowelOrConsonant(char x){
//      if (x == 'a' || x == 'e' || x == 'i' || x == 'o' || x == 'u' || x == 'A' || x == 'E' || x == 'I' || x == 'O' || x == 'U'){
//          cout<<"Vowel"<<endl;
//      }
//      else{
//          cout<<"Consonant"<<endl;
//      }
//  }
//  int main(){
//      char x;
//      cout<<"Enter the character for checking!"<<endl;
//      cin>>x;
//      vowelOrConsonant(x);
//      return 0;
//  }

// C++ Program to Check Leap Year
// #include <iostream>
// using namespace std;
// bool isYear(int year)
// {
//     if (year % 400 == 0)
//     {
//         cout << "Year is leap year!" << endl;
//     }
//     else if (year % 100 == 0)
//     {
//         cout << "Year is not leap year!" << endl;
//     }
//     else if (year % 4 == 0)
//     {
//         cout << "Year is leap year!" << endl;
//     }
//     else
//     {
//         cout << "Year is leap year!" << endl;
//     }
// }
// int main()
// {
//     int x;
//     cout << "Enter the Year for checking!" << endl;
//     cin >> x;
//     isYear(x);
//     return 0;
// }

// C++ Program to Print Multiplication Table of a Number
// #include <iostream>
// using namespace std;
// int main()
// {
//     int n;
//     cout << "Enter the number for finding it's multiplication table: " << endl;
//     cin >> n;
//     cout << "Multiplication Table: " << endl;
//     for (int i = 1; i <= 10; i++)
//     {
//         cout << n << " * " << i << " = " << n * i << endl;
//     }
// }

// C++ Program to Find the Sum of Natural Numbers(first n natural numbers)
// #include <iostream>
// using namespace std;

// int findSum(int n)
// {
//     int sum = 0;
//     for (int i = 1; i <= n; i++)
//     {
//         sum = sum + i;
//     }
//     cout << "The Sum of first 'n' Natural Numbers: " << sum << endl;
// }
// int main()
// {
//     int n;
//     cout << "Enter n for getting sum: " << endl;
//     cin >> n;
//     findSum(n);
//     return 0;
// }

// C++ Program To Find Factorial Of a Number
// #include<iostream>
// using namespace std;
// int factorial(int n){
//     int fact=1;
//     for(int i=1;i<=n;i++){
//         fact = fact * i;
//     }
//     cout << "The factorial of first 'n' Natural Numbers: " << fact << endl;
// }
// int main(){
//     int n;
//     cout << "Enter n for getting factorial: " << endl;
//     cin >> n;
//     factorial(n);
//     return 0;
// }

// C++ Program to Reverse a Number
// #include<iostream>
// using namespace std;
// int reverse(int num){
//     int rev_num=0;
//     while(num>0){
//         rev_num=rev_num*10+num%10;
//         num=num/10;
//     }
//     return rev_num;
// }
// int main(){
//     int num;
//     cout<<"Enter the number : "<<endl;
//     cin>>num;
//     cout << "Reversed number is : "<< reverse(num);
//     //getchar() why??
//     return 0;
// }

// C++ Program to Find GCD
// int gcd(int a, int b)
// {
//     // Find Minimum of a and b
//     int result = min(a, b);
//     while (result > 0)
//     {
//         if (a % result == 0 && b % result == 0)
//         {
//             break;
//         }
//         result--;
//     }

//     // Return gcd of a and b
//     return result;
// }

// C++ Program to Find GCD(euclidean)(which is really)
// #include<iostream>
// using namespace std;
// int gcd(int a,int b){
//     if(a==0){
//         return b;
//     }
//     if(b==0){
//         return a;
//     }

//     if(a==b){
//         return a;
//     }

//     if (a > b){
//         return gcd(a - b, b);
//     }

//     else{
//     return gcd(a, b - a);
//     }
// }
// int main(){
//     int a,b;
//     cout<<"Enter the numbers : "<<endl;
//     cin>>a>>b;
//     cout << "GCD of " << a << " and " << b << " is " << gcd(a, b);
//     return 0;
// }

// C++ Program to Find LCM
// Method 1 :
// #include <iostream>
// using namespace std;
// int main(){
//     int a,b,max_num,flag=1;
//     cout<<"Enter both numbers for which LCM to be found"<<endl;
//     cin>>a>>b;
//     max_num=(a>b)?a:b;
//     while(flag){
//     if(max_num % a == 0 && max_num % b == 0){
//         cout << "LCM of " << a << " and " << b << " is " << max_num;
//         break;
//     }
//     ++max_num;
// }
// return 0;
// }

// Method 2:
//  #include <iostream>
//  #include<numeric>
//  using namespace std;
//  int main()
//  {
//      int a,b,num;
//      cout << "Enter both numbers for which LCM to be found" << endl;
//      cin>>a>>b;
//      cout << "LCM of " << a << " and " << b << " is " << lcm(a, b) << endl;
//      return 0;
//  }

// Method 3: I found this method most difficult
// #include <iostream>
// using namespace std;
// // Recursive function to return gcd of a and b
// long long gcd(long long int a, long long int b)
// {
//     if (b == 0)
//         return a;

//     return gcd(b, a % b);
// }

// // Function to return LCM of two numbers
// long long lcm(int a, int b) { return (a / gcd(a, b)) * b; }
// int main()
// {
//     int a = 15, b = 20;
//     cout << "LCM of " << a << " and " << b << " is "<< lcm(a, b);
//     return 0;
// }

//  C++ Program to Check Whether a Number is a Palindrome or Not:
// Method 1: By using string functions
// C++ program to find LCM of two numbers
// #include <iostream>
// using namespace std;
// int checkPalindrome(string str){
//     int len = str.length();
//     for(int i=0;i<len/2;i++){
//         if(str[i]!=str[len-i-1]){
//             return false;
//         }
//     }
//     return true;
// }
// int main()
// {
//     string str;
//     cout<<"Enter the string : ";
//     // cin>>str;
//     //  for(int i=0;i<str.length();i++){
//     //     cin>>str[i];
//     // }

//     getline(cin, str);

//     if (checkPalindrome(str) == true)
//         cout << "Yes";
//     else
//         cout << "No";
//     return 0;
// }

// Method 2 : I found this method more difficult
//  A recursive C++ program to check whether a given number is palindrome or not
// #include <iostream>
// using namespace std;

// // A function that returns true only if num contains one digit
// int oneDigit(int num)
// {
//     // Comparison operation is faster than division operation. So using following instead of "return num
//     return (num >= 0 && num < 10);
// }

// // A recursive function to find out whether num is palindrome or not. Initially, dupNum contains address of a copy of num.
// bool isPalUtil(int num, int *dupNum)
// {
//     // Base case (needed for recursion termination): This statement mainly compares the first digit with the last digit
//     if (oneDigit(num))
//         return (num == (*dupNum) % 10);

//     // This is the key line in this method. Note that all recursive calls have a separate copy of num, but they all share same copy of *dupNum. We divide num while moving up the recursion tree
//     if (!isPalUtil(num / 10, dupNum))
//         return false;

//     // The following statements are executed when we move up the recursion call tree
//     *dupNum /= 10;

//     // At this point, if num%10 contains i'th digit from beginning, then (*dupNum)%10 contains i'th digit from end
//     return (num % 10 == (*dupNum) % 10);
// }

// // The main function that uses recursive function isPalUtil() to find out whether num is palindrome or not
// int isPal(int num)
// {

//     // Check if num is negative, make it positive
//     if (num < 0)
//         num = -num;
//     // Create a separate copy of num,so that modifications made to address dupNum don't change the input number.
//     int *dupNum = new int(num);

//     return isPalUtil(num, dupNum);
// }

// int main()
// {
//     int n = 12321;
//     isPal(n) ? cout << "Yes" : cout << "No" << endl;

//     n = 12;
//     isPal(n) ? cout << "Yes" : cout << "No" << endl;

//     n = 88;
//     isPal(n) ? cout << "Yes" : cout << "No" << endl;

//     n = 8999;
//     isPal(n) ? cout << "Yes" : cout << "No";
//     return 0;
// }

//  C++ Program to Check Whether a Number is Prime or Not
// #include<iostream>
// using namespace std;
// int isPrime(int n){
// if (n<=1){
//     return false;
// }
//     for(int i=2;i<=n/2;i++){
//         if(n%i==0){
//             return false;
//         }
//     }
//     return true;
// }
// int main(){
//     int n;
//     cout<<"Enter the number to check whether it is prime or not : "<<endl;
//     cin>>n;
// // isPrime(n); don't write calling statement here
//     if (isPrime(n) == true)
//         cout << "It is prime number";
//     else
//         cout << "It is not prime number";
//     return 0;
// }

//  C++ Program to Display Prime Numbers Between Two Intervals:
// C++ program to find the
// prime numbers between a
// given interval
// #include <bits/stdc++.h>
// using namespace std;

// // Driver code
// int main()
// {
//     // Declare the variables
//     int a, b, i, j, flag;

//     // Ask user to enter lower value
//     // of interval
//     cout << "Enter lower bound of the interval: ";

//     // Take input
//     cin >> a;

//     // Ask user to enter upper value
//     // of interval
//     cout << "Enter upper bound of the interval: ";

//     // Take input
//     cin >> b;

//     // Print display message
//     cout << "Prime numbers between " << a << " and " << b
//          << " are: ";

//     // Traverse each number in the interval
//     // with the help of for loop
//     for (i = a; i <= b; i++)
//     {
//         // Skip 0 and 1 as they are
//         // neither prime nor composite
//         if (i == 1 || i == 0)
//             continue;

//         // flag variable to tell
//         // if i is prime or not
//         flag = 1;

//         for (j = 2; j <= i / 2; ++j)
//         {
//             if (i % j == 0)
//             {
//                 flag = 0;
//                 break;
//             }
//         }

//         // flag = 1 means i is prime
//         // and flag = 0 means i is not prime
//         if (flag == 1)
//             cout << i << " ";
//     }

//     return 0;
// }
// This was normal method

// method 2 : Optimized solution
//  C++ program to find the prime numbers
//  between a given interval
// #include <bits/stdc++.h>
// using namespace std;

// // Driver code
// int main()
// {
//     // Declare the variables
//     int a, b, i, j;

//     // Ask user to enter lower value of
//     // interval please not interval < 0
//     // cannot be prime numbers
//     cout << "Enter lower bound of the interval: ";

//     // Take input
//     cin >> a;

//     // Ask user to enter upper value
//     // of interval
//     cout << "Enter upper bound of the interval: ";

//     // Take input
//     cin >> b;

//     // Print display message
//     cout << "Prime numbers between " << a << " and " << b
//          << " are: ";

//     // Explicitly handling the cases
//     // when a is less than 2 since 0
//     // and 1 are not prime numbers
//     if (a <= 2)
//     {
//         a = 2;
//         if (b >= 2)
//         {
//             cout << a << " ";
//             a++;
//         }
//     }

//     // Making sure that a is odd before
//     // beginning the loop
//     if (a % 2 == 0)
//         a++;

//     // NOTE : We traverse through
//     // odd numbers only
//     for (i = a; i <= b; i = i + 2)
//     {
//         // flag variable to tell
//         // if i is prime or not
//         bool flag = 1;

//         // We traverse till square root of j only.
//         // (Largest possible value of prime factor)
//         for (j = 2; j * j <= i; ++j)
//         {
//             if (i % j == 0)
//             {
//                 flag = 0;
//                 break;
//             }
//         }

//         // flag = 1 means i is prime
//         // and flag = 0 means i is
//         // not prime
//         if (flag == 1)
//         {
//             if (i == 1)
//                 continue;
//             else
//                 cout << i << " ";
//         }
//     }

//     return 0;
// }

// Method 3: Sieve of Eratosthenes Method
// C++ program to find the prime numbers
// between a given interval using Sieve of Eratosthenes
// #include <bits/stdc++.h>
// using namespace std;

// void SieveOfEratosthenes(int srt, int n)
// {
//     // Create a boolean array "prime[srt to n]" and
//     // initialize all entries it as true. A value in
//     // prime[i] will finally be false if i is Not a prime,
//     // else true.
//     bool prime[n + 2 - srt];
//     memset(prime, true, sizeof(prime));
//     prime[0] = false;
//     prime[1] = false;

//     for (int p = srt; p * p <= n; p++)
//     {
//         // If prime[p] is not changed, then it is a prime
//         if (prime[p] == true)
//         {
//             // Update all multiples of p greater than or
//             // equal to the square of it numbers which are
//             // multiple of p and are less than p^2 are
//             // already been marked.
//             for (int i = p * p; i <= n; i += p)
//                 prime[i] = false;
//         }
//     }

//     // Print all prime numbers
//     for (int p = srt; p <= n; p++)
//         if (prime[p])
//             cout << p << " ";
// }

// // Driver Code
// int main()
// {
//     int srt = 1;
//     int end = 10;
//     SieveOfEratosthenes(srt, end);
//     return 0;
// }

//   C++ Program to Check Neon Numbers in a Given Range
//  #include<iostream>
//  #include<math.h>
//  using namespace std;
//  int checkNeon(int x){
//      int sq = x * x;
//      int sum_digits=0;
//      while(sq!=0){
//      sum_digits= sum_digits + sq%10;
//      sq=sq/10;
//      }
//      return(sum_digits==x);
//  }

// int main(){
//     int n; //upper limit of range
//     cin>>n;
//     for(int x=1;x<=n;x++){
//         if (checkNeon(x))
//             cout << x << " ";
//     }
// }

//  C++ Program to Check Armstrong Number

//  C++ Program to Display Armstrong Numbers Between 1 to 1000
// Brute force method:
// C++ program to find Armstrong numbers
// between 1 to 1000 using a brute force
// approach
// #include <bits/stdc++.h>
// using namespace std;

// // Function to return the order of
// // a number.
// int order(int num)
// {
//     int count = 0;
//     while (num > 0)
//     {
//         num /= 10;
//         count++;
//     }
//     return count;
// }

// // Function to check whether the
// // given number is Armstrong number
// // or not
// bool isArmstrong(int num)
// {
//     int order_n = order(num);
//     int num_temp = num, sum = 0;

//     while (num_temp > 0)
//     {
//         int curr = num_temp % 10;
//         sum += pow(curr, order_n);
//         num_temp /= 10;
//     }
//     if (sum == num)
//     {
//         return true;
//     }
//     else
//     {
//         return false;
//     }
// }

// // Driver code
// int main()
// {

//     cout << "Armstrong numbers between 1 to 1000 : ";
//     // Loop which will run from 1 to 1000
//     for (int num = 1; num <= 1000; ++num)
//     {

//         if (isArmstrong(num))
//         {
//             cout << num << " ";
//         }
//     }
//     return 0;
// }

// Optimized method:
//  C++ program to find Armstrong numbers
//  between 1 to 1000 using an optimized
//  solution
// #include <bits/stdc++.h>
// using namespace std;

// // Driver code
// int main()
// {
//     int ord1, ord2, ord3, total_sum;

//     cout << "All the Armstrong numbers between 1 to 1000 : ";

//     // Loop which will run from 1 to 1000
//     for (int num = 1; num <= 1000; ++num)
//     {
//         // All the single-digit numbers are
//         // armstrong number.
//         if (num <= 9)
//         {
//             cout << num << " ";
//         }
//         else
//         {
//             ord1 = num % 10;
//             ord2 = (num % 100 - ord1) / 10;
//             ord3 = (num % 1000 - ord2) / 100;

//             total_sum = ((ord1 * ord1 * ord1) +
//                          (ord2 * ord2 * ord2) +
//                          (ord3 * ord3 * ord3));
//             if (total_sum == num)
//             {
//                 cout << num << " ";
//             }
//         }
//     }
//     return 0;
// }

//  C++ Program to For Fibonacci Number:
// https://www.geeksforgeeks.org/cpp-program-for-fibonacci-numbers/
// refer 8 methods of fibonacci series

//  C++ Sum of Fibonacci Numbers at Even Indexes up to N Terms

//  C++ Program to Calculate the Power of a Number
// C++ program to illustrate
// power function
// #include <bits/stdc++.h>
// using namespace std;

// int main()
// {
//     double x = 6.1, y = 4.8;

//     // Storing the answer in result.
//     double result = pow(x, y);

//     // printing the result upto 2
//     // decimal place
//     cout << fixed << setprecision(2) << result << endl;

//     return 0;
// }

// C++ program to illustrate
// working with integers in
// power function
// #include <bits/stdc++.h>
// using namespace std;
// int main()
// {
//     int a, b;

//     // Using typecasting for
//     // integer result
//     a = (int)(pow(5, 2) + 0.5);
//     b = round(pow(5, 2));
//     cout << a << endl
//          << b;

//     return 0;
// }

//  C++ Program to Display Factors of a Natural Number
// C++ implementation of Naive
// method to print all divisors
// #include <iostream>
// using namespace std;

// // Function to print the divisors
// void printDivisors(int n)
// {
//     for (int i = 1; i <= n; i++)
//         if (n % i == 0)
//             cout << " " << i;
// }

// // Driver code
// int main()
// {
//     cout << "The divisors of 100 are: ";
//     printDivisors(100);
//     return 0;
// }

// A Better (than Naive) Solution
// to find all divisors
// #include <iostream>
// #include <math.h>
// using namespace std;

// // Function to print the divisors
// void printDivisors(int n)
// {
//     // Note that this loop runs
//     // till square root
//     for (int i = 1; i <= sqrt(n); i++)
//     {
//         if (n % i == 0)
//         {
//             // If divisors are equal,
//             // print only one
//             if (n / i == i)
//                 cout << " " << i;

//             // Otherwise print both
//             else
//                 cout << " " << i << " " << n / i;
//         }
//     }
// }

// // Driver code
// int main()
// {
//     cout << "The divisors of 100 are: ";
//     printDivisors(100);
//     return 0;
// }

//  C++ Program to Make a Simple Calculator
// C++ program to create calculator using
// switch statement
// #include <iostream>
// using namespace std;

// // Driver code
// int main()
// {
//     char op;
//     float num1, num2;
//     // It allows user to enter operator
//     // i.e. +, -, *, /
//     cin >> op;

//     // It allow user to enter the operands
//     cin >> num1 >> num2;

//     // Switch statement begins
//     switch (op)
//     {
//     // If user enter +
//     case '+':
//         cout << num1 + num2;
//         break;
//     // If user enter -
//     case '-':
//         cout << num1 - num2;
//         break;
//     // If user enter *
//     case '*':
//         cout << num1 * num2;
//         break;
//     // If user enter /
//     case '/':
//         cout << num1 / num2;
//         break;
//     // If the operator is other than +, -, * or /,
//     // error message will display
//     default:
//         cout << "Error! operator is not correct";
//     }
//     // switch statement ends
//     return 0;
// }

// out of 21 : 6 programs are difficult and just copied/wanted to copy and out of 6 : for 2 programs spaces are blank.