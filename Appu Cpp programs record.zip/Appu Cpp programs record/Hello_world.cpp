//Hello world printing program:
#include<iostream>
using namespace std;
int main(){
    cout<<"Hello World";
}