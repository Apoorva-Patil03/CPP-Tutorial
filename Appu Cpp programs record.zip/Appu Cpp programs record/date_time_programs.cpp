#include<iostream>
#include <string.h>
using namespace std;
int main (){
    string str = "Hello World";
    cout << str.size() << endl;          // 1st method
    cout << str.length() << endl;        // 2nd method
    cout << strlen(str.c_str()) << endl; // 3rd method

    int i = 0;
    while (str[i])
        i++;
    cout << i << endl; // 4th method

    for (i = 0; str[i]; i++) ; //I got here that we won't get error even we give ';' in front of loop
    cout << i << endl;
}