#include <iostream>
using namespace std;
int checkPalindrome(string str){
    int len = str.length();
    for(int i=0;i<len/2;i++){
        if(str[i]!=str[len-i-1]){
            return false;
        }
    }
    return true;
}
int main()
{
    string str;
    cout<<"Enter the string : ";
    // cin>>str;
    //  for(int i=0;i<str.length();i++){
    //     cin>>str[i];
    // }

    getline(cin, str);

    if (checkPalindrome(str) == true)
        cout << "Yes";
    else
        cout << "No";
    return 0;
}