// C++ Program To Print Right Half Pyramid Pattern:
// #include <iostream>
// using namespace std;
// int main()
// {
//     int rows;
//     cout<<"Enter the number of rows of pyramid: "<<endl;
//     cin>>rows;
//     for (int i = 0; i < rows; i++)
//     {
//         for (int j = 0; j <= i; j++)
//         {
//             cout << "*";
//         }
//         cout<<"\n";
//     }
// }

// C++ Program To Print Left Half Pyramid Pattern :
// #include <iostream>
// using namespace std;
// int main()
// {
//     int rows;
//     cout << "Enter the number of rows of pyramid: " << endl;
//     cin >> rows;
//     for (int i = rows; i > 0; i--)
//     {
//         for (int j = 0; j <= rows; j++)  //as i=rows like refer analogy with above program
//         {
//             if (j >= i)  //remember it
//             { 
//                 cout << "*";
//             }
//             else
//             {
//                 cout << " ";
//             }
//         }
//         cout << "\n";
//     }
// }


// C++ Program To Print Number Pattern
// #include <iostream>
// using namespace std;
// int main()
// {
//     int rows;
//     cout<<"Enter the number of rows of pyramid: "<<endl;
//     cin>>rows;
//     for (int i = 1; i <=rows; i++)
//     {
//         for (int j = 1; j <= i; j++)
//         {
//             cout<<j<<" ";
//         }
//         cout<<"\n";
//     }
// }

// #include <iostream>
// using namespace std;
// int main()
// {
//     int rows;
//     cout << "Enter the number of rows of pyramid: " << endl;
//     cin >> rows;
//     for (int i = 1; i <= rows; i++)
//     {
//         for (int j = 1; j <= i; j++)
//         {
//             cout << i << " ";
//         }
//         cout << "\n";
//     }
// }

// #include <iostream>
// using namespace std;
// int main()
// {
//     int rows,number=1;
//     cout << "Enter the number of rows of pyramid: " << endl;
//     cin >> rows;
//     for (int i = 1; i <= rows; i++)
//     {
//         for (int j = 1; j <= i; j++)
//         {
//             cout << number << " ";
//             number++;
//         }
//         cout << "\n";
//     }
// }

// C++ Program To Print Inverted Pyramid(left)
// #include <iostream>
// using namespace std;
// int main()
// {
//     int rows;
//     cout << "Enter the number of rows of pyramid: " << endl;
//     cin >> rows;
//     for (int i = rows; i >= 1; --i)
//     {
//         for (int j = 1; j <= i; j++)
//         {
//             cout << " * ";
//         }
//         cout << "\n";
//     }
// }

// C++ Program To Print Inverted Pyramid(right) (please look for it is bit confusing)
// #include <iostream>
// using namespace std;
// int main()
// {
//     int rows;
//     cout << "Enter the number of rows of pyramid: " << endl;
//     cin >> rows;
//     for (int i = 1; i <= rows; --i)
//     {
//         for (int j = 1; j < i; j++)
//         {
//             if(j>=i){
//                 cout << " * ";
//             }
//             else{
//                 cout<<" ";
//             }
//         }
//         cout << "\n";
//     }
// }

// C++ Program to print an inverted half pyramid using numbers
// #include <iostream>
// using namespace std;
// int main()
// {
//     int rows;
//     cout << "Enter the number of rows of pyramid: " << endl;
//     cin >> rows;
//     for (int i = rows; i >= 1; --i)
//     {
//         for (int j = 1; j <= i; j++)
//         {
//             cout << j <<" ";
//         }
//         cout << "\n";
//     }
// }

// Program to print inverted full pyramid using ” * “ (please look for it is bit confusing)
// #include <iostream>
// using namespace std;
// int main()
// {
//     int rows;
//     cout << "Enter the number of rows of pyramid: " << endl;
//     cin >> rows;
//     for (int i = rows; i >= 1; --i)
//     {
//         for (int j = 1; j <= i; j++)
//         {
//             if(i=rows){
//                 cout << " * ";
//             }
//             else{
//                 cout<<" ";
//             }
//         }
//         cout << "\n";
//     }
// }

// C++ Program To Print Triangle Pattern
// C++ Program To Print Number Pattern without reassigning
// C++ Program To Print Character Pattern
// C++ Program To Print Continuous Character Pattern
// C++ Program To Print Full Diamond Shape Pyramid
// C++ Program To Print Inverted Hollow Star Pyramid Pattern 
// C++ Program To Print Hollow Star Pyramid in a Diamond Shape
// C++ Program To Print Pascal’s Triangle
// C++ Program To Print Floyd’s pattern Triangle Pyramid
// C++ Program To Print Reverse Floyd Pattern Triangle Pyramid
