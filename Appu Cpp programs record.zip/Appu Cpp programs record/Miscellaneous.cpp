// C++ Program to Find Quotient and Remainder
#include <iostream>
using namespace std;
int main()
{
    int Dividend, Quotient, Divisor, Remainder;

    cout << "Enter Dividend & Divisor: "; // use formula of dividend=(divisor*quotient)+remainder
    cin >> Dividend >> Divisor;

    Quotient = Dividend / Divisor;
    Remainder = Dividend % Divisor;

    cout << "The Quotient = " << Quotient << endl;
    cout << "The Remainder = " << Remainder << endl;
    return 0;
}

// C++ Program to Find Initials of a Name (please look after it is difficult)

#include <iostream>
using namespace std;
void printTheInitials(int str)
{
}
int main()
{
}
// C++  Program to Find Power Without Using * and / Operators
// #include<iostream>
// using namespace std;
// int pow(int a, int b)
// {
//     if (b == 0)
//         return 1;
//     int answer = a;
//     int increment = a;
//     int i, j;
//     for (i = 1; i < b; i++)
//     {
//         for (j = 1; j < a; j++)
//         {
//             answer += increment;
//         }
//         increment = answer;
//     }
//     return answer;
// }
// int main()
// {
//     int a,b;
//     cout << "Enter value of base and power to find: "<<endl;
//     cin>>a>>b;
//     return 0;
// }

// C++ Program to Find the Roots of the Quadratic Equation
// #include <iostream>
// #include<math.h>
// #include<bits/stdc++.h> can use this instead of above both libraries
// using namespace std;
// Prints roots of quadratic equation
// ax*2 + bx + x
// void findRoots(int a, int b, int c)
// {
// If a is 0, then equation is
// not quadratic, but linear
//     if (a == 0)
//     {
//         cout << "Invalid";
//         return;
//     }

//     int d = b * b - 4 * a * c;
//     double sqrt_val = sqrt(abs(d));

//     if (d > 0)
//     {
//         cout << "Roots are real and different ";
//         cout << (double)(-b + sqrt_val) / (2 * a) << " "
//              << (double)(-b - sqrt_val) / (2 * a);
//     }
//     else if (d == 0)
//     {
//         cout << "Roots are real and same ";
//         cout << -(double)b / (2 * a);
//     }

// d < 0
//     else
//     {
//         cout << "Roots are complex ";
//         cout << -(double)b / (2 * a) << " + i"
//              << sqrt_val / (2 * a) << " "
//              << -(double)b / (2 * a) << " - i"
//              << sqrt_val / (2 * a);
//     }
// }
// int main()
// {
//     int a, b, c;
//     cout << "Enter value of a,b,c to find root of quadratic equation : " << endl;
//     cin >> a >> b >> c;
//     return 0;
// }

// Generate Random Double Numbers in C++  (please look after it is difficult and different)
// How to Hide and Show a Console Window in C++? (please look after it is difficult and different)
// How to Run a C++ Program Without Namespace?
#include <iostream>
#include <string>
int main()
{
    //just use std::cout instead of line 'using namespace std;'
    std::cout << "geeksforgeeks";
    return 0;
}

// Build a custom Map using a Header File in C++ (please look after it is difficult and uses tree)
// C++ Program for Number of Unique Triplets Whose XOR is Zero (please look after it is difficult and use set)