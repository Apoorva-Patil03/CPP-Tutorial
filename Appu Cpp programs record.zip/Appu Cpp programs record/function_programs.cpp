// #include <iostream>
// using namespace std;
// int primeOrNot(int l, int r)
// {
//     int i, j;
//     for (i = l; i <= r; i++)
//     {
//         if (i == 0 || i == 1)
//         {
//             continue;
//             // cout<<"Neither Prime Nor Composite";
//         }

//         bool isPrime = true; // Assume i is prime until proven otherwise
//         for (int j = 2; j * j <= i; j++)    i <= sqrt(n)(alternative of this for condition)
//         {
//             if (i % j == 0)
//             {
//                 isPrime = false;
//                 break;
//             }
//         }

//         if (isPrime)
//         {
//             cout << i << " ";
//         }
//     }
// }

// void primeInRange(int L, int R) //this is old approach and simplest one remember this one
// {
// for (int i = L; i <= R; i++)
// {
//     if (i <= 1)
//         continue; // Skip 0 and 1

//     int j;
//     for (j = 2; j < i; j++)
//     {
//         if (i % j == 0)
//             break; // Found a factor, so break the loop
//     }

//     if (j == i)
//     {
//         std::cout << i << " ";
//     }
// }
// }

// int main()
// {
//     int l, r;
//     cout << "Enter start and end of range: " << endl;
//     cin >> l >> r;
//     primeOrNot(l, r);
// }

// The Sum of Natural Numbers Using Recursion
// #include<iostream>
// using namespace std;
// int recSum(int n){
//     if(n<=1){
//         return n;
//     }
//     return n + recSum(n - 1);
// }
// int main(){
//     int n;
//     cout<<"Enter n here : ";
//     cin>>n;
//     cout<<recSum(n);
// }

// C++ Program to Find Factorial of a Large Number Using Recursion
// #include <iostream>
// using namespace std;
// int recFact(int n)
// {
//     if (n <= 1)
//     {
//         return n;
//     }
//     return n * recFact(n - 1);
// }

// int main()
// {
//     int n;
//     cout << "Enter n here : ";
//     cin >> n;
//     cout << recFact(n);
// }



// C++ Program to Reverse a Sentence Using Recursion(look after it is difficult for me)
//  #include <iostream>
//  using namespace std;
//  char reverse(string str)
//  {
//      if (str.size() == 0)
//      {
//          return 'a';
//      }
//      reverse(str.substr(1));
//      cout << str[0];
//  }
//  int main()
//  {
//      string str;
//      cout << "Enter a string : " << endl;
//      cin >> str;
//      cout<<reverse(str);
//      return 0;
//  }

// C++ Program To Calculate the Power of a Number
// #include <iostream>
// using namespace std;
// long power(int x, unsigned n)
// {
//     int pow = 1;
//     for (int i = 1; i <= n; i++)
//     {
//         pow = pow * x;
//     }
//     return pow;
// }
// int main()
// {
//     int x, n;
//     cout << "Enter the number and power whose value to be found : " << endl;
//     cin >> x >> n;
//     cout << power(x, n);
//     return 0;
// }

// C++ Program For Variadic Function Templates
